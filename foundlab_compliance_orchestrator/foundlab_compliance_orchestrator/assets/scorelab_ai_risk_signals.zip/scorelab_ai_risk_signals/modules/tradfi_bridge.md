## TradFi Bridge

Integração entre dados financeiros tradicionais e score reputacional dinâmico.