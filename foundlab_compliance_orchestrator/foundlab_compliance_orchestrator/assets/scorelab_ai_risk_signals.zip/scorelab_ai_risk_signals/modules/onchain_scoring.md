## Onchain Scoring

Modelo de score reputacional baseado em transações e contratos analisados.