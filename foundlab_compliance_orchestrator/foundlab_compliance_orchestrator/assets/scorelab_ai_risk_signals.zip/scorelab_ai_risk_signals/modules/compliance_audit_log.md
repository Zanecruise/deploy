## Compliance Audit Log

Exportação automatizada de logs compatíveis com normas de auditoria.