## Prompt Templates

Estrutura para gerar análise automatizada com base em eventos financeiros e reputacionais.