## Revenue Simulation

Modelo de simulação de receita baseado em eventos processados, clientes ativos e tiers de produto.