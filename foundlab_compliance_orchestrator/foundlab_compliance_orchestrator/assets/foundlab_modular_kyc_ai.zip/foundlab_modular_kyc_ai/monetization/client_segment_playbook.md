## Client Segment Playbook

Estratégia de penetração por segmento: fintech, marketplace, SaaS, bancos digitais.