## SDK Adapter

Integração plugável com apps/web, APIs REST/gRPC, onboarding instantâneo.