## Biometric Engine

Processamento, scoring e autenticação por biometria comportamental.