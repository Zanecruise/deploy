## Microservice Diagram

Overview dos principais microserviços: minting, auditoria, compliance, metadata bridge.