## Audit Exporter

Exportação de trilha de auditoria compatível com normativos globais.