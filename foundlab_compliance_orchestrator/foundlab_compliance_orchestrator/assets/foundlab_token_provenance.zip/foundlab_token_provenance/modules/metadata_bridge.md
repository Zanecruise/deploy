## Metadata Bridge

Ponte para integrar metadata off-chain e registro on-chain de NFT.