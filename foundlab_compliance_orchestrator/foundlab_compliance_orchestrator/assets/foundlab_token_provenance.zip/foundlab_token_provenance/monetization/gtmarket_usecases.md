## Go-to-Market Use Cases

Exemplos de uso: onboarding de cliente jurídico, tokenização de documento oficial, integração marketplace.